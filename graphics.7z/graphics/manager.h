#pragma once

#include <utils/MS/graphics/d2d.h>
#include <utils/MS/graphics/d2d/window.h>

namespace utils::graphics
	{
	class font;
	class solid_brush;
	class window;

	class manager
		{
		friend class font;
		friend class solid_brush;
		friend class window;

		public:

		private:
			utils::MS::graphics::co  ::initializer    co_initializer;
			utils::MS::graphics::d2d ::factory        d2d_factory;
			utils::MS::graphics::d3d ::device         d3d_device;
			utils::MS::graphics::dxgi::device         dxgi_device{d3d_device};
			utils::MS::graphics::d2d ::device         d2d_device{d2d_factory, dxgi_device};
			utils::MS::graphics::dw  ::factory        dw_factory;
			utils::MS::graphics::d2d ::device_context d2d_device_context{d2d_device};
		};

	class window : public utils::MS::graphics::d2d::window::render_target
		{
		public:
			using on_draw_signature = utils::MS::graphics::d2d::window::render_target::on_draw_signature;

			struct create_info
				{
				friend class utils::graphics::window;
				public:
					using module_type = utils::graphics::window;
					manager& manager;
					std::function<on_draw_signature> on_render;

					inline void adjust_base_create_info(utils::MS::window::base::create_info& base_create_info) const noexcept
						{
						get_parent_create_info().adjust_base_create_info(base_create_info);
						}

				private:
					utils::MS::graphics::d2d::window::render_target::create_info get_parent_create_info() const noexcept
						{
						return {.d2d_factory{manager.d2d_factory}, .on_render{on_render}};
						}
				};

			window(utils::MS::window::base& base, const create_info& create_info) : utils::MS::graphics::d2d::window::render_target{base, create_info.get_parent_create_info()} {}
		};

	class font
		{
		public:
			using create_info = utils::MS::graphics::dw::text_format::create_info;

			font(manager& manager, const create_info& create_info) : dw_text_format{manager.dw_factory, create_info} {}

		private:
			utils::MS::graphics::dw::text_format dw_text_format;
		};

	class solid_brush
		{
		public:
			solid_brush(manager& manager, utils::graphics::colour::rgba_f rgba_f) : d2d_brush_solid{manager.d2d_device_context, rgba_f} {}

		private:
			utils::MS::graphics::d2d::solid_brush d2d_brush_solid;
		};
	}