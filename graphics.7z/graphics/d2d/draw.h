#pragma once

namespace utils::graphics::d2d
	{

	}